/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

import static DTO.Categoria.*;
import static DTO.TipoProducto.*;
import java.time.LocalDateTime;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 *
 * @author likep
 */
public class Producto {
    private int cod_producto;
    private int stock;
    private String descripcion;
    private Usuario admin_crea;
    private Usuario admin_modifica;
    private LocalDateTime fecha_mod;
    private LocalDateTime fecha_creacion;
    private Categoria categoria;
    private double precio;
    private TipoProducto tipoProducto;
    private LinkedHashSet<Marca> marca;
    
    public Producto(){
        
    }

    public Producto(int cod_producto, int stock, String descripcion, Usuario admin_crea, Usuario admin_modifica, LocalDateTime fecha_mod, LocalDateTime fecha_creacion, Categoria categoria, double precio, TipoProducto tipoProducto, Set<Marca> marca) {
        this.cod_producto = cod_producto;
        this.stock = stock;
        this.descripcion = descripcion;
        this.admin_crea = admin_crea;
        this.admin_modifica = admin_modifica;
        this.fecha_mod = fecha_mod;
        this.fecha_creacion = fecha_creacion;
        this.categoria = categoria;
        this.precio = precio;
        this.tipoProducto = tipoProducto;
        this.marca = new LinkedHashSet<>(marca);
    }

    public int getCod_producto() {
        return cod_producto;
    }

    public void setCod_producto(int cod_producto) {
        this.cod_producto = cod_producto;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Usuario getAdmin_crea() {
        return admin_crea;
    }

    public void setAdmin_crea(Usuario admin_crea) {
        this.admin_crea = admin_crea;
    }

    public Usuario getAdmin_modifica() {
        return admin_modifica;
    }

    public void setAdmin_modifica(Usuario admin_modifica) {
        this.admin_modifica = admin_modifica;
    }

    public LocalDateTime getFecha_mod() {
        return fecha_mod;
    }

    public void setFecha_mod(LocalDateTime fecha_mod) {
        this.fecha_mod = fecha_mod;
    }

    public LocalDateTime getFecha_creacion() {
        return fecha_creacion;
    }

    public void setFecha_creacion(LocalDateTime fecha_creacion) {
        this.fecha_creacion = fecha_creacion;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public TipoProducto getTipoProducto() {
        return tipoProducto;
    }

    public void setTipoProducto(TipoProducto tipoProducto) {
        this.tipoProducto = tipoProducto;
    }

    public LinkedHashSet<Marca> getMarca() {
        return new LinkedHashSet<>(marca);
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 97 * hash + this.cod_producto;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Producto other = (Producto) obj;
        return this.cod_producto == other.cod_producto;
    }

    
    
    public static TipoProducto tipoProductoIndex(int id){
        switch (id) {
            case 1 -> {
                return Pack_Especial;
            }
            case 2 -> {
                return Pack_Eventual;
            }
            case 3 -> {
                return Cubos;
            }
            case 4 -> {
                return Cervezas;
            }
        }
        return nada;
    }
    
    public static Categoria categoriaSegunIndex(int id){
        switch (id) {
            case 1 -> {
                return Rubia;
            }
            case 2 -> {
                return Malta;
            }
            case 3 -> {
                return Tostada;
            }
        }
        return Nada;
    }

    @Override
    public String toString() {
        return "Producto{" + "cod_producto=" + cod_producto + ", stock=" + stock + ", descripcion=" + descripcion + ", admin_crea=" + admin_crea + ", admin_modifica=" + admin_modifica + ", fecha_mod=" + fecha_mod + ", fecha_creacion=" + fecha_creacion + ", categoria=" + categoria + ", precio=" + precio + ", tipoProducto=" + tipoProducto + ", marca=" + marca + '}';
    }
    
    
    
    
    


    
    
    
}
