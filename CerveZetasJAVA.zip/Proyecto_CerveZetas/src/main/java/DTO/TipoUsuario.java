/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package DTO;

/**
 *
 * @author likep
 */
public enum TipoUsuario {
    Cliente, Admin, Visitante;
    
    @Override
    public String toString(){
        switch (this) {
            case Cliente -> {
                return "Cliente";
            }
            case  Admin -> {
                return "Administrador";
            }
        }
        return null;
    }
}
