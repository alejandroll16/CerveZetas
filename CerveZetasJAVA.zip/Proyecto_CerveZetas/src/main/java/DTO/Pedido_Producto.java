/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

import java.util.Objects;

/**
 *
 * @author likep
 */
public class Pedido_Producto {
    
    private int cod_pedido;
    private int num_factura;
    private Producto producto;
    private double precio;
    private int cantidad;

    
    public Pedido_Producto() {
        
    }
    
    

    public Pedido_Producto(int cod_pedido, int num_factura, Producto producto, double precio, int cantidad) {
        this.cod_pedido = cod_pedido;
        this.num_factura = num_factura;
        this.producto = producto;
        this.precio = precio;
        this.cantidad = cantidad;
    }
    
   
    public int getCod_pedido() {
        return cod_pedido;
    }

    public int getNum_factura() {
        return num_factura;
    }

    public Producto getProducto() {
        return producto;
    }

    public double getPrecio() {
        return precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 83 * hash + this.cod_pedido;
        hash = 83 * hash + this.num_factura;
        hash = 83 * hash + Objects.hashCode(this.producto);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Pedido_Producto other = (Pedido_Producto) obj;
        if (this.cod_pedido != other.cod_pedido) {
            return false;
        }
        if (this.num_factura != other.num_factura) {
            return false;
        }
        return Objects.equals(this.producto, other.producto);
    }



    @Override
    public String toString() {
        return "Pedido_Producto{" + "cod_pedido=" + cod_pedido + ", num_factura=" + num_factura + ", producto=" + producto + ", precio=" + precio + ", cantidad=" + cantidad + '}';
    }
    
    
    
}
