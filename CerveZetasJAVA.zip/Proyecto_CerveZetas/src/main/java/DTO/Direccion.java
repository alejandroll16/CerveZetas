/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;
import static DTO.tipoVia.*;
import static DTO.tipoDireccion.*;
import java.util.Objects;

/**
 *
 * @author likep
 */
public class Direccion {
    private int codigo_direccion;
    private Usuario email_usuario;
    private int numero;
    private String Municipio;
    private int codigoPostal;
    private String provincia;
    private tipoVia tipoVia;
    private tipoDireccion tipoDireccion;
    private String nombre;

    public Direccion(int codigo_direccion, Usuario email_usuario, int numero, String Municipio, int codigoPostal, String provincia, tipoVia tipoVia, tipoDireccion tipoDireccion, String nombre) {
        this.codigo_direccion = codigo_direccion;
        this.email_usuario = email_usuario;
        this.numero = numero;
        this.Municipio = Municipio;
        this.codigoPostal = codigoPostal;
        this.provincia = provincia;
        this.tipoVia = tipoVia;
        this.tipoDireccion = tipoDireccion;
        this.nombre = nombre;
    }

    public int getCodigo_direccion() {
        return codigo_direccion;
    }

    public void setCodigo_direccion(int codigo_direccion) {
        this.codigo_direccion = codigo_direccion;
    }

    public Usuario getEmail_usuario() {
        return email_usuario;
    }

    public void setEmail_usuario(Usuario email_usuario) {
        this.email_usuario = email_usuario;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getMunicipio() {
        return Municipio;
    }

    public void setMunicipio(String Municipio) {
        this.Municipio = Municipio;
    }

    public int getCodigoPostal() {
        return codigoPostal;
    }

    public void setCodigoPostal(int codigoPostal) {
        this.codigoPostal = codigoPostal;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public tipoVia getTipoVia() {
        return tipoVia;
    }

    public void setTipoVia(tipoVia tipoVia) {
        this.tipoVia = tipoVia;
    }

    public tipoDireccion getTipoDireccion() {
        return tipoDireccion;
    }

    public void setTipoDireccion(tipoDireccion tipoDireccion) {
        this.tipoDireccion = tipoDireccion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 89 * hash + this.codigo_direccion;
        hash = 89 * hash + Objects.hashCode(this.email_usuario);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Direccion other = (Direccion) obj;
        if (this.codigo_direccion != other.codigo_direccion) {
            return false;
        }
        return Objects.equals(this.email_usuario, other.email_usuario);
    }


    
    public static tipoDireccion direccionSegunIndex(int id){
        switch (id) {
            case 1 -> {
                return Casa;
            }
            case 2 -> {
                return  Trabajo;
            }
            case 3 -> {
                return Campo;
            }
            case 4 -> {
                return Chalet;
            }
        }
        return nada;
    }
    
    public static tipoVia viaSegunIndex(int id){
        switch (id) {
            case 1 -> {
                return Calle;
            }
            case 2 -> {
                return Avenida;
            }
            case 3 -> {
                return Plaza;
            }
        }
        return ninguna;
    }
    
    @Override
    public String toString() {
        return "Direccion{" + "codigo_direccion=" + codigo_direccion + ", email_usuario=" + email_usuario + ", numero=" + numero + ", Municipio=" + Municipio + ", codigoPostal=" + codigoPostal + ", provincia=" + provincia + ", tipoVia=" + tipoVia + ", tipoDireccion=" + tipoDireccion + ", nombre=" + nombre + '}';
    }
    
    
    
}
