/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package DTO;

/**
 *
 * @author likep
 */
public enum tipoVia {
    
    Calle, Avenida, Plaza, ninguna;

    @Override
    public String toString(){
        switch (this) {
            case Calle -> {
                return "Calle";
            }
            case Avenida -> {
                return "Avenida";
            }
            case Plaza -> {
                return "Plaza";
            }
        }
        
        return "nada";
    }
    
}
