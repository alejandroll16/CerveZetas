/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

import java.time.LocalDateTime;


/**
 *
 * @author likep
 */
public class Pedido_Factura {
    private int cod_pedido;
    private int num_factura;
    private LocalDateTime fecha_factura;
    private Direccion direccion;
    private Usuario cliente;


    public Pedido_Factura(int cod_pedido, int num_factura, LocalDateTime fecha_factura, Direccion direccion, Usuario cliente) {
        this.cod_pedido = cod_pedido;
        this.num_factura = num_factura;
        this.fecha_factura = fecha_factura;
        this.direccion = direccion;
        this.cliente = cliente;

    }

    public int getCod_pedido() {
        return cod_pedido;
    }

    public void setCod_pedido(int cod_pedido) {
        this.cod_pedido = cod_pedido;
    }

    public int getNum_factura() {
        return num_factura;
    }

    public void setNum_factura(int num_factura) {
        this.num_factura = num_factura;
    }

    public LocalDateTime getFecha_factura() {
        return fecha_factura;
    }

    public void setFecha_factura(LocalDateTime fecha_factura) {
        this.fecha_factura = fecha_factura;
    }

    public Direccion getDireccion() {
        return direccion;
    }

    public void setDireccion(Direccion direccion) {
        this.direccion = direccion;
    }

    public Usuario getCliente() {
        return cliente;
    }

    public void setCliente(Usuario cliente) {
        this.cliente = cliente;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 71 * hash + this.cod_pedido;
        hash = 71 * hash + this.num_factura;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Pedido_Factura other = (Pedido_Factura) obj;
        if (this.cod_pedido != other.cod_pedido) {
            return false;
        }
        return this.num_factura == other.num_factura;
    }

    
    public double getPrecio_total() {
        Pedido_Producto linea = new Pedido_Producto();
        
        double precio_total = linea.getCantidad()*linea.getPrecio();
        
        return precio_total;
    }



    @Override
    public String toString() {
        return "Pedido_Factura{" + "cod_pedido=" + cod_pedido + ", num_factura=" + num_factura + ", fecha_factura=" + fecha_factura + ", direccion=" + direccion + ", cliente=" + cliente + ", precio_total=" + getPrecio_total() + '}';
    }
    
    
    

   
    
    
    
    
}
