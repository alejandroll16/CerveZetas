/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package DTO;

/**
 *
 * @author likep
 */
public enum TipoProducto {
    Pack_Eventual,Pack_Especial,  Cubos, Cervezas, nada;
    
    @Override
    public String toString(){
        switch (this) {
            case Pack_Eventual -> {
                return "Pack Eventual";
            }
            case Pack_Especial -> {
                return "Pack Especial";
            }
            case Cubos -> {
                return "Cubo";
            }
            case Cervezas -> {
                return "Cervezas";
            }
        }
        
        return "Sin alcohol";
    }
}
