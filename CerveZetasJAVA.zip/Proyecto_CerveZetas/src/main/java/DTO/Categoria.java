/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package DTO;

/**
 *
 * @author likep
 */
public enum Categoria {
    Rubia, Malta, Tostada, Nada;
    
    @Override
    public String toString(){
        switch (this) {
            case Rubia -> {
                return "Rubia";
            }
            case Malta -> {
                return "Malta";
            }
            case Tostada -> {
                return "Tostada";
            }
        }
        
        return "agua";
    }
    
    
}
