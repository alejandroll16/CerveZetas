/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package DTO;

/**
 *
 * @author likep
 */
public enum tipoDireccion {
    Casa, Trabajo, Campo, Chalet, nada;
    
    @Override
    public String toString(){
        switch (this) {
            case Casa -> {
                return "Casa";
            }
            case Trabajo -> {
                return "Trabajo";
            }
            case Campo -> {
                return "Campo";
            }
            case Chalet -> {
                return "Chalet";
            }
        }
        return null;
    }
}
