/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

import static DTO.MetodoPago.*;
import static DTO.TipoUsuario.*;
import java.time.LocalDateTime;
import java.util.Objects;

/**
 *
 * @author likep
 */
public class Usuario {
    
    private String email;
    private String nombre;
    private String apellidos;
    private String contrasena;
    private int telefono;
    private LocalDateTime ultima_concexion;
    private LocalDateTime fecha_nacimiento;
    private String foto;
    private TipoUsuario tipo_usuarios;
    private MetodoPago metodo_pago;
    
    public static final String PATRON_CONTRASENYA = "^(?=.*\\d)[a-zA-Z0-9]{8,}$";
    public static final String PATRON_EMAIL = "^[a-zA-Z0-9._%+-]+@gmail\\.com$";

    public Usuario() {
    }

    public Usuario(String email, String nombre, String apellidos, String contrasena, int telefono, LocalDateTime ultima_concexion, LocalDateTime fecha_nacimiento, String foto, TipoUsuario tipo_usuarios, MetodoPago metodo_pago) {
        this.email = email;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.contrasena = contrasena;
        this.telefono = telefono;
        this.ultima_concexion = ultima_concexion;
        this.fecha_nacimiento = fecha_nacimiento;
        this.foto = foto;
        this.tipo_usuarios = tipo_usuarios;
        this.metodo_pago = metodo_pago;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public LocalDateTime getUltima_concexion() {
        return ultima_concexion;
    }

    public void setUltima_concexion(LocalDateTime ultima_concexion) {
        this.ultima_concexion = ultima_concexion;
    }

    public LocalDateTime getFecha_nacimiento() {
        return fecha_nacimiento;
    }

    public void setFecha_nacimiento(LocalDateTime fecha_nacimiento) {
        this.fecha_nacimiento = fecha_nacimiento;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public TipoUsuario getTipo_usuarios() {
        return tipo_usuarios;
    }

    public void setTipo_usuarios(TipoUsuario tipo_usuarios) {
        this.tipo_usuarios = tipo_usuarios;
    }

    public MetodoPago getMetodo_pago() {
        return metodo_pago;
    }

    public void setMetodo_pago(MetodoPago metodo_pago) {
        this.metodo_pago = metodo_pago;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 41 * hash + Objects.hashCode(this.email);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Usuario other = (Usuario) obj;
        return Objects.equals(this.email, other.email);
    }


    
    public static TipoUsuario tipoUserIndex(int id){
        switch (id) {
            case 1 -> {
                return Cliente;
            }
            case  2 -> {             
                return Admin;
            }
        }
        
        return Visitante;
    }
    
    public static MetodoPago metodoSegunIndex(int id){
        switch (id) {
            case 1 -> {
                return PayPal;
            }
            case 2 -> {
                return Tarjeta;
            }
            case 3 -> {
                return MonedaVirtual;
            }
        }
        return nada;
    }

    @Override
    public String toString() {
        return "Usuario{" + "email=" + email + ", nombre=" + nombre + ", apellidos=" + apellidos + ", contrasena=" + contrasena + ", telefono=" + telefono + ", ultima_concexion=" + ultima_concexion + ", fecha_nacimiento=" + fecha_nacimiento + ", foto=" + foto + ", tipo_usuarios=" + tipo_usuarios + ", metodo_pago=" + metodo_pago + '}';
    }
    
    
    
    
}
