/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import DTO.Direccion;
import DTO.Usuario;
import DTO.tipoDireccion;
import DTO.tipoVia;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author likep
 */
public class DireccionDAO extends TablaDAO<Direccion> {

    public DireccionDAO() {
        this.tabla = "CerveZetas_Direccion";
    }

    @Override
    public int actualizar(Direccion objeto) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int anyadir(Direccion objeto) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Direccion eliminar(Direccion objeto) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean existe(Direccion objeto) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public ArrayList<Direccion> getAll() throws SQLException {
        ArrayList<Direccion> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " ORDER BY codigo_direccion";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo_direccion");
            Usuario usuario = new UsuarioDAO().getByemail(resultSet.getString("email_usuario"));
            int numeroPuerta = resultSet.getInt("numero");
            String nombreCalle = resultSet.getString("nombre");
            String municipio = resultSet.getString("Municipio");
            String provincia = resultSet.getString("provincia");
            int cp = resultSet.getInt("CodigoPostal");
            tipoDireccion direcciones = tipoDireccion.valueOf(resultSet.getString("tipoDireccion"));
            tipoVia vias = tipoVia.valueOf(resultSet.getString("tipoVia"));

            lista.add(new Direccion(codigo, usuario, numeroPuerta, municipio, cp, provincia, vias, direcciones, nombreCalle));

        }
        return lista;
    }

    @Override
    public Direccion getByCodigo(int cod) throws SQLException {
         String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE codigo_direccion=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, cod);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo_direccion");
            Usuario usuario = new UsuarioDAO().getByCodigo(resultSet.getInt("email"));
            int numeroPuerta = resultSet.getInt("numero");
            String nombreCalle = resultSet.getString("nombre");
            String municipio = resultSet.getString("Municipio");
            String provincia = resultSet.getString("provincia");
            int cp = resultSet.getInt("CodigoPostal");
            tipoDireccion direcciones = tipoDireccion.valueOf(resultSet.getString("tipoDireccion"));
            tipoVia vias = tipoVia.valueOf(resultSet.getString("tipoVia"));
            
            return new Direccion(codigo, usuario, numeroPuerta, municipio, cp, provincia, vias, direcciones, nombreCalle);
        }
        
        return null;
    }
     public ArrayList<Direccion> getDireccionesDe(Usuario u) throws SQLException {
        ArrayList<Direccion> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE email_usuario=? ORDER BY codigo_direccion";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setString(1, u.getEmail());
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            
            int codigo = resultSet.getInt("codigo_direccion");
            Usuario usuario = new UsuarioDAO().getByCodigo(resultSet.getInt("email"));
            int numeroPuerta = resultSet.getInt("numero");
            String nombreCalle = resultSet.getString("nombre");
            String municipio = resultSet.getString("Municipio");
            String provincia = resultSet.getString("provincia");
            int cp = resultSet.getInt("CodigoPostal");
            tipoDireccion direcciones = tipoDireccion.valueOf(resultSet.getString("tipoDireccion"));
            tipoVia vias = tipoVia.valueOf(resultSet.getString("tipoVia"));
            
            lista.add(new Direccion(codigo, usuario, numeroPuerta, municipio, cp, provincia, vias, direcciones, nombreCalle));

        }
         return lista;
    }
}


