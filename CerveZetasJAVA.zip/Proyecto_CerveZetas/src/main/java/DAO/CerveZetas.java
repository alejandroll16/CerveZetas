/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import java.sql.SQLException;

/**
 *
 * @author ciclost
 */
public class CerveZetas {
    
    public static void main(String[] args) throws SQLException {
        MarcaDAO marca = new MarcaDAO();
        UsuarioDAO user = new UsuarioDAO();
        ProductoDAO producto = new ProductoDAO();
        PedidoDAO pedido = new PedidoDAO();
        DireccionDAO direccion = new DireccionDAO();
        FacturaDAO factura = new FacturaDAO();
        
        System.out.println(marca.getAll());
        System.out.println(user.getAll());
        System.out.println(producto.getAll());
        System.out.println(pedido.getAll());
        System.out.println(direccion.getAll());
        System.out.println(factura.getAll());
        
    }
    
}
