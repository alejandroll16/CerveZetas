/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import DTO.Categoria;
import DTO.Marca;
import DTO.Producto;
import DTO.TipoProducto;
import DTO.Usuario;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashSet;

/**
 *
 * @author likep
 */
public class ProductoDAO extends TablaDAO<Producto> {
    
    public ProductoDAO(){
        this.tabla = "CerveZetas_Producto";
    }

    @Override
    public int actualizar(Producto objeto) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int anyadir(Producto p) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody

    }

    @Override
    public Producto eliminar(Producto p) throws SQLException {
        if (p == null) {
            return null;
        } else {
            return eliminar(p.getCod_producto()) != null ? p : null;
        }
    }

    @Override
    public boolean existe(Producto p) throws SQLException {
        return existe(p.getCod_producto());
    }

    @Override
    public ArrayList<Producto> getAll() throws SQLException {
        ArrayList<Producto> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " ORDER BY cod_producto";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int cod_producto = resultSet.getInt("cod_producto");
            int stock = resultSet.getInt("stock");
            String descripcion = resultSet.getString("descripcion");
            Usuario admin_crea = new UsuarioDAO().getByemail(resultSet.getString("admin_crea"));
            LocalDateTime fecha_creacion = resultSet.getTimestamp("fecha_creacion").toLocalDateTime();
            Usuario admin_modifica = new UsuarioDAO().getByemail(resultSet.getString("admin_modifica"));
            Timestamp fechaModificacionTS = resultSet.getTimestamp("fecha_mod");
            LocalDateTime fechaModificacion = (fechaModificacionTS == null) ? null : fechaModificacionTS.toLocalDateTime();
            double precio = resultSet.getDouble("precio");
            TipoProducto tipoProducto = TipoProducto.valueOf(resultSet.getString("TipoProducto"));
            Categoria categorias = Categoria.valueOf(resultSet.getString("Categoria"));
            LinkedHashSet<Marca> marca = getMarcaByCodProducto(cod_producto);

            lista.add(new Producto(cod_producto, stock, descripcion, admin_crea, admin_modifica, fecha_creacion, fechaModificacion, categorias, precio, tipoProducto, marca));

        }

        return lista;
    }

    public LinkedHashSet<Marca> getMarcaByCodProducto(int cod_producto) throws SQLException {
        LinkedHashSet<Marca> marcas = new LinkedHashSet<>();
        String sentenciaSQL = "SELECT ma.codigo, ma.nombre FROM CerveZetas_Producto pr, CerveZetas_Marca ma WHERE ma.codigo = pr.marca AND pr.cod_producto = ?  ORDER BY ma.codigo";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, cod_producto);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo");
            String nombre = resultSet.getString("nombre");
            marcas.add(new Marca(codigo, nombre));
        }
        return marcas;

    }

    @Override
    public Producto getByCodigo(int codigo) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE cod_producto=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigo);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int cod_producto = resultSet.getInt("cod_producto");
            int stock = resultSet.getInt("stock");
            String descripcion = resultSet.getString("descripcion");
            Usuario admin_crea = new UsuarioDAO().getByemail(resultSet.getString("admin_crea"));
            LocalDateTime fecha_creacion = resultSet.getTimestamp("fecha_creacion").toLocalDateTime();
            Usuario admin_modifica = new UsuarioDAO().getByemail(resultSet.getString("admin_modifica"));
            Timestamp fechaModificacionTS = resultSet.getTimestamp("fecha_mod");
            LocalDateTime fechaModificacion = (fechaModificacionTS == null) ? null : fechaModificacionTS.toLocalDateTime();
            TipoProducto tipoProducto = TipoProducto.valueOf(resultSet.getString("TipoProducto"));
            Categoria categorias = Categoria.valueOf(resultSet.getString("Categoria"));
            LinkedHashSet<Marca> marca = getMarcaByCodProducto(cod_producto);

            return new Producto(cod_producto, stock, descripcion, admin_crea, admin_modifica, fecha_creacion, fechaModificacion, categorias, stock, tipoProducto, marca);

        }

        return null;

    }

}
