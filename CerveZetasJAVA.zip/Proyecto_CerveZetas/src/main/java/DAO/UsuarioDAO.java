/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import DTO.MetodoPago;
import DTO.TipoUsuario;
import DTO.Usuario;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;

/**
 *
 * @author ciclost
 */
public class UsuarioDAO extends TablaDAO<Usuario>{
    
    public UsuarioDAO(){
        this.tabla = "CerveZetas_Usuario";
    }
    
    @Override
    public int actualizar(Usuario objeto) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int anyadir(Usuario objeto) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Usuario eliminar(Usuario objeto) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean existe(Usuario objeto) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public ArrayList<Usuario> getAll() throws SQLException {
        ArrayList<Usuario> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " ORDER BY email";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            String email = resultSet.getString("email");
            String nombre = resultSet.getString("nombre");
            String apellidos = resultSet.getString("apellidos");
            String contrasena = resultSet.getString("contrasena");
            int telefono = resultSet.getInt("telefono");
            String foto = resultSet.getString("foto");
            Timestamp fechaNacimientoTS = resultSet.getTimestamp("fecha_nacimiento");
            LocalDateTime fechaNacimiento = fechaNacimientoTS == null?null:fechaNacimientoTS.toLocalDateTime();
            MetodoPago metodoPago = MetodoPago.valueOf(resultSet.getString("metodo_pago"));
            TipoUsuario tipoUsuario = TipoUsuario.valueOf(resultSet.getString("tipo_usuarios"));
            Timestamp ultimaConexionTS = resultSet.getTimestamp("ultima_conexion");
            LocalDateTime ultima_conexion = ultimaConexionTS == null ? null : ultimaConexionTS.toLocalDateTime();
            lista.add(new Usuario(email, nombre, apellidos, contrasena, telefono, ultima_conexion, fechaNacimiento, foto, tipoUsuario, metodoPago));
        }

        return lista;
    }

    @Override
    public Usuario getByCodigo(int codigo) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    public Usuario getByemail(String email) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE email=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setString(1, email);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            String nombre = resultSet.getString("nombre");
            String apellidos = resultSet.getString("apellidos");
            String contrasena = resultSet.getString("contrasena");
            int telefono = resultSet.getInt("telefono");
            String foto = resultSet.getString("foto");
            Timestamp fechaNacimientoTS = resultSet.getTimestamp("fecha_nacimiento");
            LocalDateTime fechaNacimiento = fechaNacimientoTS == null?null:fechaNacimientoTS.toLocalDateTime();
            MetodoPago metodoPago = MetodoPago.valueOf(resultSet.getString("metodo_pago"));
            TipoUsuario tipoUsuario = TipoUsuario.valueOf(resultSet.getString("tipo_usuarios"));
            Timestamp ultimaConexionTS = resultSet.getTimestamp("ultima_conexion");
            LocalDateTime ultima_conexion = ultimaConexionTS == null ? null : ultimaConexionTS.toLocalDateTime();
            return new Usuario(email, nombre, apellidos, contrasena, telefono, ultima_conexion, fechaNacimiento, foto, tipoUsuario, metodoPago);
        }
        
 
        return null;
    }
}
