/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import DTO.Direccion;
import DTO.Pedido_Factura;
import DTO.Usuario;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;

/**
 *
 * @author likep
 */
public class FacturaDAO extends TablaDAO<Pedido_Factura>{
    
    public FacturaDAO(){
        this.tabla = "CerveZetas_Pedido_Factura";
    }

    @Override
    public int actualizar(Pedido_Factura objeto) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int anyadir(Pedido_Factura f) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Pedido_Factura eliminar(Pedido_Factura f) throws SQLException {
        if (f == null) {
            return null;
        } else {
            return eliminar(f.getNum_factura()) != null ? f : null;
        }
    }

    @Override
    public boolean existe(Pedido_Factura factura) throws SQLException {
        return existe(factura.getNum_factura());
    }

    @Override
    public ArrayList<Pedido_Factura> getAll() throws SQLException {
        ArrayList<Pedido_Factura> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " ORDER BY cod_pedido";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int cod_pedido = resultSet.getInt("cod_pedido");
            int num_factura = resultSet.getInt("num_factura");
            LocalDateTime fecha_factura = resultSet.getTimestamp("fecha_factura").toLocalDateTime();
            Direccion direcciones = new DireccionDAO().getByCodigo(resultSet.getInt("direccion"));
            Usuario usuario = new  UsuarioDAO().getByemail(resultSet.getString("cliente"));
            
             
            lista.add(new Pedido_Factura(cod_pedido, num_factura, fecha_factura, direcciones, usuario));
            
        }
        return lista;
    }

    @Override
    public Pedido_Factura getByCodigo(int codigo) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE cod_pedido=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigo);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
             int cod_pedido = resultSet.getInt("cod_pedido");
            int num_factura = resultSet.getInt("num_factura");
            LocalDateTime fecha_factura = resultSet.getTimestamp("fecha_factura").toLocalDateTime();
            Direccion direcciones = new DireccionDAO().getByCodigo(resultSet.getInt("direccion"));
            Usuario usuario = new  UsuarioDAO().getByemail(resultSet.getString("cliente"));
        
            return new Pedido_Factura(cod_pedido, num_factura, fecha_factura, direcciones, usuario);
        }
        
        return null;
    }
    
}
