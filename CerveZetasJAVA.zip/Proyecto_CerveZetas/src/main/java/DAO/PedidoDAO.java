/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import DTO.Pedido_Producto;
import DTO.Producto;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author likep
 */
public class PedidoDAO extends TablaDAO<Pedido_Producto>{
    
    public PedidoDAO(){
        this.tabla = "CerveZetas_Pedido_Producto";
    }

    @Override
    public int actualizar(Pedido_Producto objeto) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int anyadir(Pedido_Producto objeto) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Pedido_Producto eliminar(Pedido_Producto objeto) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean existe(Pedido_Producto objeto) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public ArrayList<Pedido_Producto> getAll() throws SQLException {
        ArrayList<Pedido_Producto> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " ORDER BY cod_pedido";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int codigo = resultSet.getInt("cod_pedido");
            int num_factura = resultSet.getInt("num_factura");
            Producto producto = new ProductoDAO().getByCodigo(resultSet.getInt("producto"));
            double total = resultSet.getDouble("precio");
            int cantidad = resultSet.getInt("cantidad");
            lista.add(new Pedido_Producto(codigo, num_factura, producto, total, cantidad));
        }

        return lista;
    }

    @Override
    public Pedido_Producto getByCodigo(int cod) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE cod_pedido=? and num_factura =?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, cod);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int codigo = resultSet.getInt("cod_pedido");
            int num_factura = resultSet.getInt("num_factura");
            Producto producto = new ProductoDAO().getByCodigo(resultSet.getInt("cod_producto"));
            double total = resultSet.getDouble("precio");
            int cantidad = resultSet.getInt("cantidad");
            
            return new Pedido_Producto(codigo, num_factura, producto, total, cantidad);
        }
        return null;
    }
    
}
